<template>
	<div id="app">
		<keep-alive><router-view /></keep-alive>
	</div>
</template>

<style>
	
</style>
