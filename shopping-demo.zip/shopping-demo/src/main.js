import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

// import MintUI from 'mint-ui'
// import 'mint-ui/lib/style.css'
// Vue.use(MintUI)
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
Vue.use(ElementUI)

import infiniteScroll from 'vue-infinite-scroll'
Vue.use(infiniteScroll)


import vueLazyLoad from 'vue-lazyload'
Vue.use(vueLazyLoad, {
	loading: require('./assets/loading/loading-bars.svg'),
})


import axios from 'axios'
Vue.prototype.axios = axios

import {
	currency
} from '../public/js/currency.js'
Vue.filter("currency", currency);

Vue.config.productionTip = false

new Vue({
	router,
	store,
	render: h => h(App)
}).$mount('#app')
