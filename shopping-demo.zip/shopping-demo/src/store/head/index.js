const state = {
	userHead: window.localStorage.getItem('name') ||''
}

const actions = {

}

const mutations = {
	HEAD_NAME(state, payload) {
		state.userHead = payload.userHead;
	}
}

export default {
	namespaced: true,
	state,
	actions,
	mutations
}
