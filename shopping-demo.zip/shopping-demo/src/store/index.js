import Vue from 'vue'
import Vuex from 'vuex'
import user from './user'
import head from './head'
import cart from './cart'
import cartnum from './cartnum'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
  },
  mutations: {
  },
  actions: {
  },
  modules: {
	  user,
	  cart,
	  head,
	  cartnum
	  
  }
})
