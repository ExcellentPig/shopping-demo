const state = {
	cartCount: window.localStorage.getItem('cartCount') || 0
}

const actions = {

}

const mutations = {
	updateCartCount(state,cartCount){
		state.cartCount +=parseInt(cartCount)
	},
	initCartCount(state,cartCount){
		state.cartCount = parseInt(cartCount)
	}
}

export default {
	namespaced: true,
	state,
	actions,
	mutations
}
