const state = {
	cartList: window.localStorage.getItem('cartList') ||[]
}

const actions = {

}

const mutations = {
	CART_NAME(state, payload) {
		state.cartList = payload.cartList;
	}
}

export default {
	namespaced: true,
	state,
	actions,
	mutations
}
