export default{
	path:'/mycart',
	component:()=>import('@/views/MyCart'),
	children: [
		{
			path: 'mycartList',
			component: () => import('@/components/MyCartList/index.vue')
		},
		{
			path: 'order',
			component: () => import('@/views/MyCart/order.vue')
		},
		{
			path: 'orderConfirm',
			component: () => import('@/views/MyCart/orderConfirm.vue')
		},
		{
			path: '/mycart',
			redirect: 'mycartList'
		}
	]
}