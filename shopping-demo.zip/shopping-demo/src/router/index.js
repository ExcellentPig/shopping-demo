import Vue from 'vue'
import VueRouter from 'vue-router'
import mineRouter from './mine'
import cartlistRouter from './cartlist'
import mycartRouter from './mycart'
import adminRouter from './admin'

Vue.use(VueRouter)

const routes = [
	mineRouter,
	cartlistRouter,
	mycartRouter,
	adminRouter,
	{
		path: '/*',
		redirect: '/cartlist'
	}
]

const router = new VueRouter({
	// mode: 'history',
	base: process.env.BASE_URL,
	routes
})

export default router
