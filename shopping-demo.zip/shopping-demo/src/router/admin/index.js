export default{
	path:'/admin',
	component:()=>import('@/views/Admin'),
	children:[
	{
		path:'userManagement',
		component:()=>import('@/views/Admin/UserManagement.vue')
	},{
		path: '/admin',
		redirect: 'userManagement'
	}
	]
}