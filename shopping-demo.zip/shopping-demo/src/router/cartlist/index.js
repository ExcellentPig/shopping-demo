export default{
	path:'/cartlist',
	component:()=>import('@/views/CartList'),
	children:[{
		path:'cartlistdetail',
		component:()=>import('@/components/CartListDetail/')
	},{
		path:'/cartlist',
		redirect:'/cartlist/cartlistdetail'
	}
	]
}