<template>
	<div>
		<Header title="我的信息" />
		<div id="content"><router-view /></div>
		<TabBar />
	</div>
</template>

<script>
import TabBar from '@/components/TabBar';
import Header from '@/components/Header';
import Login from '@/components/Login';
export default {
	name: 'Mine',
	components: {
		TabBar,
		Header,
		Login
	}
};
</script>

<style scoped="scoped"></style>
