<template>
	<div class="center">
		<div class="a">
			<img :src="$store.state.head.userHead" class="avatar" />
			<div>
				<a href="javascript:;" class="a-upload">
					<input @change="handleToUpload" type="file" name="file"/>
					点击这里上头像
				</a>
			</div>
		</div>
		<div class="name">用户名:{{ $store.state.user.name }}</div>
		<div class="b" v-if="$store.state.user.isAdmin">
			用户身份:管理员
			<router-link tag="a" target="_blank" to="/admin">点击进入管理后台</router-link>
		</div>
		<div class="c" v-else>用户身份:普通会员</div>
		<div class="d"><a href="javascript:;" @touchend="handToLogout">退出登录</a></div>
	</div>
</template>

<script>
import { messageBox } from '@/components/JS';
import axios from 'axios';
export default {
	name: 'center',
	data() {
		return {
			imageUrl: '123456'
		};
	},
	methods: {
		handToLogout() {
			this.axios.get('/users/logout').then(res => {
				var status = res.data.status;
				if (status === 0) {
					localStorage.removeItem('name');
					localStorage.removeItem('userId');
					localStorage.removeItem('userHead');
					localStorage.removeItem('cartList');
					localStorage.removeItem('cartCount');
					localStorage.removeItem('isAdmin');
					this.$store.commit('cartnum/updateCartCount',{cartCount:''})
					this.$store.commit('user/USER_NAME', { name: '',userId:'',isAdmin:false});
					this.$store.commit('head/HEAD_NAME',{userHead: '' })
					this.$store.commit('cart/CART_NAME',{cartList: ''})
					this.$router.push('/mine/login');
				}
			});
		},
		handleToUpload(ev) {
			var file = ev.target.files[0];
			var param = new FormData();
			param.append('file',file,file.name);
			
			var config = {
				headers:{
					'Content-Type':'multipart/form-data'
				}
			}
			
			this.axios.post('/users/uploadUserHead',param,config)
				.then((res)=>{
					var status = res.data.status;
					var This = this;
					if(status === 0){
						messageBox({
							title:'信息',
							content:'上传头像成功',
							ok:'确定',
							handleOk(){
								This.$store.commit('head/HEAD_NAME',{
									userHead:res.data.data.userHead+'?'+Math.random()
								})
							}
						})
					}else{
						messageBox({
							title:'信息',
							content:'上传头像失败',
							ok:'确定',
						})
					}
				})
		}
	},
	beforeRouteEnter(to, from, next) {
		axios.get('/users/getUser?token='+Math.random()).then(res => {
			var status = res.data.status;
			if (status === 0) {
				next(vm => {
					localStorage.setItem('name', res.data.data.userName);
					localStorage.setItem('isAdmin', res.data.data.isAdmin);
					localStorage.setItem('userId', res.data.data.userId);
					localStorage.setItem('userHead', res.data.data.userHead);
					vm.$store.commit('user/USER_NAME', { name: res.data.data.userName, userId: res.data.data.userId,isAdmin:res.data.data.isAdmin });
					vm.$store.commit('head/HEAD_NAME', { userHead: res.data.data.userHead });
					localStorage.setItem('cartList', res.data.data.cartList);
					vm.$store.commit('cart/CART_NAME', { cartList: res.data.data.cartList });
				});
			} else {
				next('/mine/login');
			}
		});
	}
};
</script>

<style scoped="scoped">
.center {
	padding: 20px 20px;
}
.a {
	margin-top: 50px;
}
.a img {
	margin: 0 auto;
}
.a-upload {
	padding: 4px 10px;
	height: 20px;
	line-height: 20px;
	position: relative;
	cursor: pointer;
	color: #888;
	background: #fafafa;
	border: 1px solid #ddd;
	border-radius: 4px;
	overflow: hidden;
	display: inline-block;
	*display: inline;
	*zoom: 1;
	margin-top: 20px;
}

.a-upload input {
	position: absolute;
	font-size: 100px;
	right: 0;
	top: 0;
	opacity: 0;
	filter: alpha(opacity=0);
	cursor: pointer;
}

.a-upload:hover {
	color: #444;
	background: #eee;
	border-color: #ccc;
	text-decoration: none;
}
.a div {
	text-align: center;
}
.b {
	margin-top: 20px;
	font-size: 20px;
}
.b a {
	color: #0074d9;
}
.c {
	margin-top: 40px;
	font-size: 20px;
}
.d {
	margin-top: 50px;
	text-align: center;
}
.d a {
	text-decoration: none;
	width: 70px;
	height: 20px;
	line-height: 20px;
	background-color: #ff7d63;
	padding: 10px;
	color: white;
	border-radius: 20px;
	font-size: 18px;
}
.name {
	margin-top: 20px;
	font-size: 20px;
	text-align: center;
}
.avatar-uploader {
	border: 2px solid #000000;
	width: 100px;
	height: 100px;
	border-radius: 50%;
	overflow: hidden;
	margin: 0 auto;
	border-radius: 50%;
	overflow: hidden;
}
.avatar-uploader .el-upload {
	border: 1px dashed #000000;
	border-radius: 6px;
	cursor: pointer;
	position: relative;
	overflow: hidden;
}
.avatar-uploader .el-upload:hover {
	border-color: #000000;
}
.avatar-uploader-icon {
	font-size: 28px;
	color: #000000;
	width: 100px;
	height: 100px;
	line-height: 100px;
	text-align: center;
}
.avatar {
	width: 100px;
	height: 100px;
	border-radius: 50%;
	overflow: hidden;
	border: 3px solid #000000;
}
</style>
