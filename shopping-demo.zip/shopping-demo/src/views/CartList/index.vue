<template>
	<div>
		<div class="topmessage">
			<div class="font3"><p>Shopping-Demo</p></div>
		</div>
		<keep-alive><router-view /></keep-alive>
		<TabBar />
	</div>
</template>

<script>
import TabBar from '@/components/TabBar';
import Header from '@/components/Header';
export default {
	name: 'CartList',
	data() {
		return {
			
		};
	},
	components: {
		TabBar,
		Header
	},
	methods:{
		
	}
};
</script>
<style scoped="scoped">
.topmessage {
	padding-top: 10px;
	padding-left: 5px;
	padding-bottom: 10px;
}
.font3 > p {
	font-size: 30px;
	text-shadow: 5px 5px 5px black, 0px 0px 2px black;
	color: lightblue;
}
</style>
