<template>
	<div>
		<div class="icon"><i class="iconfont icon-zhifu"></i></div>
		<div class="message">
			<p>支付成功!</p>
			<p>用户ID:{{ orderId }}</p>
			<p>支付金额:{{ orderTotal | currency('￥') }}</p>
		</div>
		<div class="back">
			<router-link class="btn1" tag="button" to="/cartlist/cartlistdetail">返回首页</router-link>
			<router-link class="btn2" tag="button" to="/mycart/mycartList">返回购物车</router-link>
		</div>
	</div>
</template>

<script>
export default {
	name: 'order',
	data() {
		return {
			orderId: '',
			orderTotal: ''
		};
	},
	mounted() {
		var orderId = this.$route.query.orderId;
		if (!orderId) {
			return;
		}
		this.axios
			.get('/carts/orderDetail', {
				params: {
					orderId: orderId
				}
			})
			.then(response => {
				let res = response.data;
				if (res.status == '0') {
					this.orderId = orderId;
					this.orderTotal = res.result.orderTotal;
				}
			});
	}
};
</script>

<style scoped="scoped">
.icon {
	width: 250px;
	height: 250px;
}
.icon-zhifu {
	font-size: 250px;
	line-height: 350px;
	margin-left: 70px;
}
.message p {
	text-align: center;
	font-size: 18px;
	margin-bottom: 10px;
	color: darkgray;
}
.message p:first-child {
	color: red;
}
.back button {
	margin-top: 50px;
	width: 150px;
	height: 40px;
	border: none;
	font-size: 20px;
	font-weight: bold;
	color: white;
}
.btn1 {
	margin-left: 30px;
	background-color: #0086b3;
}
.btn2 {
	margin-left: 20px;
	background-color: #ff7d63;
}
</style>
