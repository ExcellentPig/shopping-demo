<template>
	<div>
		<div class="conta">
			<div class="cartli" v-for="item in cartList" v-if="item.checked == true" :key="item.id">
				<div class="img">
					<div class="two"><img v-lazy="item.productImage" /></div>
					<div class="three">
						<p>{{ item.productName }}</p>
						<span>单价:{{ item.salePrice | currency('￥') }}</span>
					</div>
				</div>
				<div class="add">
					<div class="mon">
						<span>数量</span>
						<span class="num">X{{ item.productNum }}</span>
					</div>
					<div class="mm">
						<span>{{ (item.salePrice * item.productNum) | currency('￥') }}</span>
					</div>
				</div>
			</div>
		</div>
		<div class="msg">
			<p>商品金额:{{ subTotal | currency('￥') }}</p>
			<p>优惠:{{ discounts | currency('￥') }}</p>
			<p>运费:{{ freight | currency('￥') }}</p>
			<p>
				总金额:
				<span>{{ orderTotal | currency('￥') }}</span>
			</p>
		</div>
		<footer id="footer">
			<div class="confirm2"><router-link tag="input" type="button" value="上一步" to="/mycart/mycartList"></router-link></div>
			<div class="confirm">
				<input type="button" value="下一步" @touchstart="payMent" />
				<!-- <router-link tag="input" type="button" value="下一步" to="/mycart/order"></router-link> -->
			</div>
		</footer>
	</div>
</template>

<script>
export default {
	name: 'orderConfirm',
	data() {
		return {
			cartList: [],
			discounts: 40,
			freight: 10,
			orderTotal: 0,
			subTotal: 0
		};
	},
	activated() {
		this.init();
	},
	methods: {
		init() {
			this.axios.get('/carts/cartList').then(response => {
				let res = response.data;
				this.cartList = res.result;
				this.cartList.forEach(item => {
					if (item.checked == true) {
						this.subTotal += item.salePrice * item.productNum;
					}
				});
				this.orderTotal = this.subTotal - this.discounts + this.freight;
			});
		},
		payMent() {
			this.axios
				.post('/carts/payMent', {
					orderTotal: this.orderTotal
				})
				.then(response => {
					let res = response.data;
					if (res.status == '0') {
						this.$router.push({
							path: '/mycart/order?orderId=' + res.result.orderId
						});
					}
				});
		}
	}
};
</script>

<style scoped="scoped">
.mm {
	margin-left: 140px;
}
.mm span {
	line-height: 40px;
	color: red;
	font-size: 20px;
}
.add div {
	float: left;
	margin-bottom: 2px;
}
.inpu {
	line-height: 40px;
	margin-left: 20px;
}
.inpu input[type='button'] {
	width: 30px;
	height: 30px;
	font-size: 20px;
	line-height: 10px;
	border: none;
	background-color: none;
}
.inpu input[type='text'] {
	width: 30px;
	height: 29px;
	vertical-align: top;
	box-sizing: border-box;
	margin-top: 5px;
	border: none;
	border-top: 1px solid #000000;
	border-bottom: 1px solid #000000;
	text-align: center;
}
.mon {
	margin-left: 10px;
}
.mon span {
	line-height: 40px;
	color: #000000;
	font-size: 15px;
}
.cartli {
	width: 95%;
	height: 170px;
	background-color: ghostwhite;
	margin: 10px auto;
	padding: 5px;
}
.cartli:last-child {
	margin-bottom: 40px;
}
.cartli .img {
	width: 100%;
	height: 130px;
	border-bottom: 1px solid #000000;
}
.img div {
	float: left;
}
.one {
	line-height: 120px;
}
.two {
	width: 105px;
	height: 105px;
	border: 1px solid #000000;
	margin-top: 10px;
	margin-left: 2px;
}
.two img {
	width: 100px;
	height: 100px;
	margin: 3px auto;
}
.three p {
	line-height: 80px;
	width: 80px;
	margin-left: 5px;
	overflow: hidden;
	white-space: nowrap;
	text-overflow: ellipsis;
}
.three span {
	margin-left: 5px;
}
.four {
	margin-left: 60px;
	line-height: 120px;
}
.el-icon-delete {
	font-size: 24px;
}
.money {
	float: left;
	line-height: 45px;
	margin-left: 15px;
	font-size: 14px;
}
.money span span {
	font-size: 18px;
	color: red;
}
.num {
	width: 20px;
	height: 20px;
	border: 1px solid #000000;
	margin-left: 10px;
	padding: 2px;
}
.checkbox {
	float: left;
	margin-top: 10px;
	margin-left: 20px;
}
.checkbox span {
	color: #440044;
	font-size: 14px;
	line-height: 25px;
	margin-left: 10px;
}
.confirm {
	float: right;
	line-height: 50px;
	margin-right: 60px;
}
.confirm input {
	width: 90px;
	height: 40px;
	border: none;
	background-color: red;
	color: white;
	font-size: 18px;
	border-radius: 40px;
}
.confirm {
	float: left;
	line-height: 50px;
	margin-left: 80px;
}
.confirm input {
	width: 90px;
	height: 40px;
	border: none;
	background-color: red;
	color: white;
	font-size: 18px;
	border-radius: 40px;
}
.confirm2 {
	float: left;
	line-height: 50px;
	margin-left: 40px;
}
.confirm2 input {
	width: 90px;
	height: 40px;
	border: none;
	background-color: red;
	color: white;
	font-size: 18px;
	border-radius: 40px;
}
.msg {
	background-color: ghostwhite;
	padding: 10px;
	margin-bottom: 120px;
}
.msg p {
	margin-bottom: 10px;
	color: darkgray;
	font-size: 20px;
}
.msg p span {
	color: red;
}
#footer {
	width: 100%;
	height: 50px;
	background: white;
	border-top: 2px #ebe8e3 solid;
	position: fixed;
	left: 0;
	bottom: 50px;
}
.cart-item-check {
	margin-top: 50px;
	margin-right: 10px;
}
.checkbox-btn {
	display: inline-block;
	width: 16px;
	height: 16px;
	background: #fff;
	border: 1px solid #999;
	border-radius: 50%;
	text-align: center;
	vertical-align: middle;
	cursor: pointer;
}

.checkbox-btn .icon-ok {
	position: relative;
	display: none;
	width: 100%;
	height: 100%;
	fill: #fff;
	-webkit-transform: scale(0.6);
	-ms-transform: scale(0.6);
	transform: scale(0.6);
	vertical-align: top;
}
</style>
