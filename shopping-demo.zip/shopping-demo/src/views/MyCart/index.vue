<template>
	<div>
		<Header title="我的购物车" />
		<div>
			<keep-alive>
				<router-view />
			</keep-alive>
		</div>
		<TabBar />
	</div>
</template>

<script>
	import TabBar from '@/components/TabBar'; 
	import Header from '@/components/Header'; 
	import MyCartList from '@/components/MyCartList'; 
	export default{
		name:"MyCart",
		components:{
			TabBar,
			Header,
			MyCartList
		}
	}
</script>

<style scoped="scoped">
	
</style>
