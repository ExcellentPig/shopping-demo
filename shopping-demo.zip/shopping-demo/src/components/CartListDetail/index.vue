<template>
	<div class="movie_body" ref="movie_body">
		<div class="filter-nav">
			<span class="sortby">Sort by:</span>
			<a href="javascript:;" class="default cur">默认</a>
			<a href="javascript:;" class="price" @touchstart="sortGoods">
				价格
				<i class="el-icon-top" v-if="sortFlag"></i>
				<i class="el-icon-bottom" v-else></i>
			</a>
			<a href="javascript:;" class="filterby stopPop" @touchstart="showFilter">价格筛选</a>
		</div>
		<div class="accessory-result">
			<!-- filter -->
			<div class="filter stopPop" id="filter" :class="{ 'filterby-show': filterBy }">
				<dl class="filter-price">
					<dt>价格:</dt>
					<dd><a href="javascript:;" @touchstart="setPriceFilter('all')" v-bind:class="{ cur: priceChecked == 'all' }">全部</a></dd>
					<dd v-for="(price, index) in priceFilter" :key="index">
						<a href="javascript:;" @touchstart="setPriceFilter(index)" :class="{ cur: priceChecked == index }">{{ price.startPrice }} - {{ price.endPrice }}</a>
					</dd>
				</dl>
			</div>
		</div>
		<div class="md-overlay" v-show="overLayFlag" @touchstart="closeFilter"></div>
		<ul>
			<li v-for="item in goodsList" :key="item.id">
				<div class="pic_show" @tap="handleToDetail">
					<img v-lazy="item.productImage" />
				</div>
				<div class="info_list">
					<h2>{{ item.productName }}</h2>
					<p>
						价格:
						<span>{{ item.salePrice | currency('￥')}}</span>
					</p>
				</div>
				<div class="btn_mall" @touchstart="addCart(item.productId)">购买</div>
			</li>
		</ul>
		<div class="load-more" v-infinite-scroll="loadMore" infinite-scroll-disabled="busy" infinite-scroll-distance="10">
			<img src="./../../assets/loading/loading-spinning-bubbles.svg" v-show="loading" />
		</div>
	</div>
</template>

<script>
import axios from 'axios';
import {messageBox} from '../JS'
export default {
	name: 'CartListDetail',
	data() {
		return {
			goodsList: [],
			priceFilter: [
				{
					startPrice: '0.00',
					endPrice: '100.00'
				},
				{
					startPrice: '100.00',
					endPrice: '500.00'
				},
				{
					startPrice: '500.00',
					endPrice: '1000.00'
				},
				{
					startPrice: '1000.00',
					endPrice: '5000.00'
				},
				{
					startPrice: '5000.00',
					endPrice: '以上'
				}
			],
			filterBy: false,
			overLayFlag: false,
			sortFlag: true,
			page: 1,
			pageSize: 4,
			loading: false,
			busy: true,
			priceChecked:'all'
		};
	},
	mounted() {
		this.getGoodList();
	},
	methods: {
		getGoodList(flag) {
			var param = {
				page: this.page,
				pageSize: this.pageSize,
				sort: this.sortFlag ? 1 : -1,
				priceLeavel:this.priceChecked
			};
			this.loading = true;
			axios
				.get('/goods/list', {
					params: param
				})
				.then(response => {
					let res = response.data;
					this.loading = false;
					if (res.status == '0') {
						if(flag){
							this.goodsList =this.goodsList.concat( res.result.list);
							if(res.result.count == 0){
								this.busy = true;
							}else{
								this.busy=false;
							}
							
						}else{
							this.goodsList = res.result.list;
							this.busy=false;
						}
					} else {
						this.goodsList = [];
					}
				});
		},
		showFilter() {
			this.filterBy = true;
			this.overLayFlag = true;
		},
		closeFilter() {
			this.filterBy = false;
			this.overLayFlag = false;
		},
		sortGoods() {
			this.sortFlag = !this.sortFlag;
			this.page = 1;
			this.getGoodList();
		},
		loadMore() {
			this.busy = true;
			setTimeout(() => {
				this.page++;
				this.getGoodList(true);
			}, 500);
		},
		setPriceFilter(index){
			this.priceChecked = index;
			this.page = 1;
			this.closeFilter();
			this.getGoodList();
		},
		handleToDetail(){
			// console.log(123)
		},
		addCart(productId){
			axios.post("/goods/addCart",{
				productId:productId
			}).then((response)=>{
				let res = response.data;
				if (res.status == '0'){
					//alert("加入成功")
					this.$store.commit('cartnum/updateCartCount',1);
					var This = this;
					messageBox({
						title:'提示',
						content:'加入购物车成功',
						ok:'前往购物车',
						cancel:'继续购物',
						handleOk(){
							This.$router.push({path:'/mycart'})
						}
					})
				}else if(res.status == "-1"){
					//alert('加入失败'+res.msg)
					var This = this;
					messageBox({
						title:'提示',
						content:res.msg,
						ok:'前往登录',
						cancel:'取消',
						handleOk(){
							This.$router.push({path:'/mine/login'})
						}
					})
				}else{
					//alert('加入失败'+res.msg)
					var This = this;
					messageBox({
						title:'提示',
						content:'未知错误,请联系管理员',
						ok:'确定'
					})
				}
			})
		}
	}
};
</script>

<style scoped="scoped">
	.btn_add{
		width: 80px;
		height: 110px;
		background-color: red;
		color: white;
		text-align: center;
		padding: 5px;
		border-radius: 50px;
	}
	.load-more {
		height: 120px;
		line-height: 120px;
		margin: 0 40%;
	}
#content .movie_body {
	flex: 1;
	overflow: auto;
}
.movie_body ul {
	margin: 0 12px;
	overflow: hidden;
}
.movie_body ul li {
	margin-top: 12px;
	display: flex;
	align-items: center;
	border-bottom: 1px #e6e6e6 solid;
	padding-bottom: 10px;
}
.movie_body ul li:last-child {
	/* padding-bottom: 65px; */
}
.movie_body .pic_show {
	width: 350px;
	height: 120px;
	border: 1px solid #000000;
	padding: 2px;
}
.movie_body .pic_show img {
	width: 100%;
	height: 100%;
}
.movie_body .info_list {
	margin-left: 10px;
	flex: 1;
	position: relative;
}
.movie_body .info_list h2 {
	font-size: 21px;
	height: 70px;
	width: 150px;
	overflow: hidden;
	white-space: nowrap;
	text-overflow: ellipsis;
}
.movie_body .info_list p {
	font-size: 16px;
	color: #666;
	width: 200px;
	overflow: hidden;
	white-space: nowrap;
	text-overflow: ellipsis;
}
.movie_body .info_list span {
	color: red;
}
.movie_body .info_list .grade {
	font-weight: 700;
	color: #faaf00;
	font-size: 15px;
}
.movie_body .btn_mall,
.movie_body .btn_pre {
	width: 120px;
	height: 37px;
	line-height: 37px;
	text-align: center;
	background-color: #f03d37;
	color: #fff;
	border-radius: 4px;
	font-size: 14px;
	cursor: pointer;
}
.movie_body .btn_pre {
	background-color: #3c9fe6;
}
.movie_body .pullDown {
	margin: 0;
	padding: 0;
	border: none;
}
.topmessage {
	padding-top: 10px;
	padding-left: 5px;
	padding-bottom: 10px;
}
.font3 > p {
	font-size: 30px;
	text-shadow: 5px 5px 5px black, 0px 0px 2px black;
	color: lightblue;
}
a {
	text-decoration: none;
	color: #605f5f;
}
.md-overlay {
	position: fixed;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	background: rgba(0, 0, 0, 0.5);
	z-index: 200;
}
.filter.filterby-show {
	right: 0;
	-webkit-transition: right 0.5s ease-out;
	transition: right 0.5s ease-out;
}
.sort-up {
	transform: rotate(180deg);
	transition: all 0.3s ease-in-out;
}
</style>
