<template>
	<div class="findPassword_body">
		<div class="findPassword_email">
			邮箱:
			<input type="text" class="findPassword_text" v-model="email" />
			<button @touchstart="handleToVerify" :disabled="disabled">{{verifyInfo}}</button>
		</div>
		<div>
			新密码:
			<input type="text" v-model="userPwd" class="findPassword_text" />
		</div>
		<div>
			验证码:
			<input type="text" class="findPassword_text" v-model="verify" />
		</div>
		<div class="findPassword_btn"><button @touchstart="handleToFindPwd">修改</button></div>
		<div class="findPassword_link">
			<router-link tag="a" to="/mine/login">立即登录</router-link>
			<router-link tag="a" to="/mine/register">立即注册</router-link>
		</div>
	</div>
</template>

<script>
import {messageBox} from '@/components/JS'
export default {
	name: 'FindPassword',
	data(){
		return {
			email:'',
			userPwd:'',
			verify:'',
			verifyInfo:'发送验证码',
			disabled:false
		}
	},
	methods:{
		handleToVerify(){
			this.axios.get("/users/verify?email="+this.email)
				.then((res)=>{
					var status = res.data.status;
					var This = this;
					if(status === 0){
						messageBox({
							title:'验证码',
							content:'验证码已发送',
							ok:'确定',
							handleOk(){
								This.countDown();
							}
						})
					}else{
						messageBox({
							title:'验证码',
							content:'验证码发送失败',
							ok:'确定'
						})
					}
				})
		},
		handleToFindPwd(){
			this.axios.post("/users/findPassword",{
				email:this.email,
				userPwd:this.userPwd,
				verify:this.verify
			}).then((res)=>{
				var status = res.data.status;
				var This = this;
				if(status === 0){
					messageBox({
						title:'修改密码',
						content:'用户修改密码成功',
						ok:'确定',
						handleOk(){
							This.$router.push("/mine/login")
						}
					})
				}else{
					messageBox({
						title:'修改密码',
						content:'用户修改密码失败',
						ok:'确定'
					})
				}
			})
		},
		countDown(){
			var count = 60;
			this.disabled = true;
			var id = setInterval(()=>{
				count--;
				this.verifyInfo = `剩余${count}秒`;
				if(count === 0){
					this.disabled = false;
					count = 60;
					this.verifyInfo = '发送验证码';
					clearInterval(id);
				}
			},1000)
		}
	}
};
</script>

<style scoped>
#content .findPassword_body {
	width: 100%;
}
.findPassword_body .findPassword_text {
	width: 100%;
	height: 40px;
	border: none;
	border-bottom: 1px #ccc solid;
	margin-bottom: 5px;
	outline: none;
	text-indent: 10px;
}
.findPassword_email {
	position: relative;
}
.findPassword_email button {
	position: absolute;
	right: 10px;
	top: 10px;
	height: 30px;
	border-radius: 3px;
	border: none;
	padding: 5px;
}
.findPassword_body .findPassword_btn {
	height: 50px;
	margin: 10px;
}
.findPassword_body .findPassword_btn button {
	width: 100%;
	height: 100%;
	background: #ff7d63;
	border-radius: 3px;
	border: none;
	display: block;
	color: white;
	font-size: 20px;
}
.findPassword_body .findPassword_link {
	display: flex;
	justify-content: space-between;
}
.findPassword_body .findPassword_link a {
	text-decoration: none;
	margin: 0 5px;
	font-size: 12px;
	color: #e54847;
}
</style>
