<template>
	<div class="movie_body" ref="movie_body">
		<svg style="position: absolute; width: 0; height: 0; overflow: hidden;" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
			<defs>
				<symbol id="icon-ok" viewBox="0 0 32 32">
					<title>ok</title>
					<path
						class="path1"
						d="M31.020 0.438c-0.512-0.363-1.135-0.507-1.757-0.406s-1.166 0.435-1.529 0.937l-17.965 24.679-5.753-5.67c-0.445-0.438-1.035-0.679-1.664-0.679s-1.219 0.241-1.664 0.679c-0.917 0.904-0.917 2.375 0 3.279l7.712 7.6c0.438 0.432 1.045 0.681 1.665 0.681l0.195-0.008c0.688-0.057 1.314-0.406 1.717-0.959l19.582-26.9c0.754-1.038 0.512-2.488-0.538-3.233z"
					></path>
				</symbol>
				<symbol id="icon-clock" viewBox="0 0 32 32">
					<title>clock</title>
					<path
						class="path1"
						fill="#605f5f"
						d="M16 29c-7.168 0-13-5.831-13-13s5.832-13 13-13c7.168 0 13 5.832 13 13s-5.832 13-13 13zM16 0c-8.822 0-16 7.178-16 16s7.178 16 16 16c8.822 0 16-7.178 16-16s-7.178-16-16-16z"
					></path>
					<path
						class="path2"
						fill="#605f5f"
						d="M23.958 21.837l-6.958-6.489v-6.282c0-0.827-0.673-1.5-1.5-1.5s-1.5 0.673-1.5 1.5v6.934c0 0.414 0.174 0.814 0.477 1.098l7.435 6.934c0.279 0.259 0.642 0.402 1.023 0.402 0.415 0 0.814-0.174 1.096-0.477 0.564-0.605 0.532-1.555-0.073-2.12z"
					></path>
				</symbol>
			</defs>
		</svg>
		<div class="conta">
			<div class="cartli" v-for="item in cartList" :key="item.id">
				<div class="img">
					<div class="cart-item-check">
						<a href="javascript:;" class="checkbox-btn item-check-btn" :class="{ checked: item.checked == true }" @touchstart="editCart('checked', item)">
							<svg class="icon icon-ok"><use xlink:href="#icon-ok"></use></svg>
						</a>
					</div>
					<div class="two"><img :src="item.productImage" /></div>
					<div class="three">
						<p>{{ item.productName }}</p>
					</div>
					<div class="four"><i @touchstart="delCartfirm(item)" class="el-icon-delete"></i></div>
				</div>
				<div class="add">
					<div class="inpu">
						<input type="button" value="-" @touchstart="editCart('minu', item)" />
						<input type="text" :value="item.productNum" />
						<input type="button" value="+" @touchstart="editCart('add', item)" />
					</div>
					<div class="mon">
						<span>{{ (item.productNum * item.salePrice) | currency('￥') }}</span>
					</div>
				</div>
			</div>
		</div>
		<footer id="footer">
			<div class="checkbox">
				<a href="javascript:;" @touchstart="toggleCheckAll" class="checkbox-btn item-check-btn" :class="{ checked: checkAllFlag }">
					<svg class="icon icon-ok"><use xlink:href="#icon-ok"></use></svg>
				</a>
				<span>全选</span>
			</div>
			<div class="money">
				<span>
					总金额:
					<span>{{ totalPrice | currency('￥') }}</span>
				</span>
			</div>
			<div class="confirm"><input type="button" value="结算" :disabled="checkedCount == 0" @touchstart="checkout" /></div>
		</footer>
	</div>
</template>

<script>
import axios from 'axios';
import { messageBox } from '@/components/JS';
export default {
	name: 'MyCartList',
	data() {
		return {
			cartList: [],
			productId: '',
			checked: true,
			delItem: {}
		};
	},
	activated() {
		this.init();
	},
	methods: {
		init() {
			this.axios.get('/carts/cartList').then(res => {
				var status = res.data.status;
				if (status == '0') {
					var a = (this.$store.state.cart.cartList = res.data.result);
					this.cartList = a;
				}
			});
		},
		delCartfirm(item) {
				this.delItem = item;
				console.log(this.delItem)
				var This = this;
				messageBox({
					title: '提示',
					content: '确认删除？',
					ok: '确定',
					cancel: '取消',
					handleOk() {
						This.delCart();
						This.init();
					}
				});
		},
		delCart() {
			this.axios
				.post('/carts/del', {
					productId: this.delItem.productId
				})
				.then(response => {
					let res = response.data;
					if (res.status == '0') {
						var delCount = this.delItem.productNum;
						console.log(delCount)
						this.$store.commit('cartnum/updateCartCount',-delCount);
					} else {
						essageBox({
							title: '提示',
							content: '删除失败，请重试',
							ok: '确定'
						});
					}
				});
		},
		editCart(flag, item) {
			if (flag == 'add') {
				item.productNum++;
			} else if (flag == 'minu') {
				if (item.productNum <= 1) {
					return;
				}
				item.productNum--;
			} else {
				item.checked = item.checked == true ? false : true;
			}
			this.axios
				.post('/carts/cartEdit', {
					productId: item.productId,
					productNum: item.productNum,
					checked: item.checked
				})
				.then(response => {
					let res = response.data;
					let num = 0;
					if(flag == 'add'){
						num=1;
					}else if(flag == 'minu'){
						num = -1
					}
					this.$store.commit('cartnum/updateCartCount',num);
				});
		},
		toggleCheckAll() {
			var flag = !this.checkAllFlag;
			this.cartList.forEach(item => {
				item.checked = flag;
			});
			this.axios
				.post('/carts/checkAll', {
					checkAll: flag ? true : false
				})
				.then(response => {
					let res = response.data;
					if (res.status == '0') {
						// console.log('suc');
					}
				});
		},
		checkout() {
			if (this.checkedCount > 0) {
				this.$router.push({
					path: '/mycart/orderConfirm'
				});
			}
		}
	},
	computed: {
		all() {
			return this.$store.state.cart.cartList;
		},
		totalPrice() {
			var money = 0;
			var sale = this.$store.state.cart.cartList;
			this.cartList.forEach(item => {
				if (item.checked == true) {
					money += parseFloat(item.salePrice) * parseInt(item.productNum);
				}
			});
			return money;
		},
		checkAllFlag() {
			return this.checkedCount == this.cartList.length;
		},
		checkedCount() {
			var i = 0;
			this.cartList.forEach(item => {
				if (item.checked == true) i++;
			});
			return i;
		}
	},
	beforeRouteEnter(to, from, next) {
		axios.get('/users/getUser?token=' + Math.random()).then(res => {
			var status = res.data.status;
			if (status === 0) {
				next(vm => {
					localStorage.setItem('name', res.data.data.userName);
					localStorage.setItem('userId', res.data.data.userId);
					localStorage.setItem('userHead', res.data.data.userHead);
					vm.$store.commit('user/USER_NAME', { name: res.data.data.userName, userId: res.data.data.userId });
					vm.$store.commit('head/HEAD_NAME', { userHead: res.data.data.userHead });
					localStorage.setItem('cartList', res.data.data.cartList);
					vm.$store.commit('cart/CART_NAME', { cartList: res.data.data.cartList });
				});
			} else {
				messageBox({
					title: '提示',
					content: '请先登录',
					ok: '确定'
				});
			}
		});
	}
};
</script>

<style scoped="scoped">
/* .check{
		check:checked
	} */
.add div {
	float: left;
	margin-bottom: 2px;
}
.inpu {
	line-height: 40px;
	margin-left: 20px;
}
.inpu input[type='button'] {
	width: 30px;
	height: 30px;
	font-size: 20px;
	line-height: 10px;
	border: none;
	background-color: none;
}
.inpu input[type='text'] {
	width: 30px;
	height: 29px;
	vertical-align: top;
	box-sizing: border-box;
	margin-top: 5px;
	border: none;
	border-top: 1px solid #000000;
	border-bottom: 1px solid #000000;
	text-align: center;
}
.mon {
	margin-left: 120px;
}
.mon span {
	line-height: 40px;
	color: red;
	font-size: 18px;
}
.cartli {
	width: 95%;
	height: 170px;
	background-color: ghostwhite;
	margin: 10px auto;
	padding: 5px;
}
.cartli:last-child {
	margin-bottom: 150px;
}
.cartli .img {
	width: 100%;
	height: 130px;
	border-bottom: 1px solid #000000;
}
.img div {
	float: left;
}
.one {
	line-height: 120px;
}
.two {
	width: 105px;
	height: 105px;
	border: 1px solid #000000;
	margin-top: 10px;
	margin-left: 2px;
}
.two img {
	width: 100px;
	height: 100px;
	margin: 3px auto;
}
.three p {
	line-height: 80px;
	width: 80px;
	margin-left: 5px;
	overflow: hidden;
	white-space: nowrap;
	text-overflow: ellipsis;
}
.four {
	margin-left: 60px;
	line-height: 120px;
}
.el-icon-delete {
	font-size: 24px;
}
.money {
	float: left;
	line-height: 45px;
	margin-left: 15px;
	font-size: 14px;
}
.money span span {
	font-size: 18px;
	color: red;
}
.checkbox {
	float: left;
	margin-top: 10px;
	margin-left: 20px;
}
.checkbox span {
	color: #440044;
	font-size: 14px;
	line-height: 25px;
	margin-left: 10px;
}
.confirm {
	float: right;
	line-height: 50px;
	margin-right: 10px;
}
.confirm input {
	width: 90px;
	height: 40px;
	border: none;
	background-color: red;
	color: white;
	font-size: 18px;
	border-radius: 40px;
}
input[disabled]{background:gray;opacity:1;color:black;}
input[type='checkbox'] {
	-webkit-appearance: none;
	-moz-appearance: none;
	appearance: none;
	width: 20px;
	height: 20px;
	border: 1px solid red;
	outline: none;
	background: transparent;
	border: 2px solid #ff7d63;
	-webkit-border-radius: 20px;
	-moz-border-radius: 20px;
	border-radius: 20px;
	margin-top: 15px;
	margin-left: 15px;
}

input[type='checkbox']::after {
	content: '✔';
	display: block;
	width: 100%;
	height: 100%;
	background: #ff7d63;
	color: #fff;
	-webkit-border-radius: 20px;
	-moz-border-radius: 20px;
	border-radius: 20px;
	text-align: center;
	transition: all ease-in-out 300ms;
	-webkit-transition: all ease-in-out 300ms;
	-moz-transition: all ease-in-out 300ms;
	opacity: 0;
}
input[type='checkbox']:checked::after {
	-webkit-border-radius: 20px;
	-moz-border-radius: 20px;
	border-radius: 20px;
	opacity: 1;
}
#content .movie_body {
	flex: 1;
	overflow: auto;
}
#footer {
	width: 100%;
	height: 50px;
	background: white;
	border-top: 2px #ebe8e3 solid;
	position: fixed;
	left: 0;
	bottom: 50px;
}
.cart-item-check {
	margin-top: 50px;
	margin-right: 10px;
}
.checkbox-btn {
	display: inline-block;
	width: 16px;
	height: 16px;
	background: #fff;
	border: 1px solid #999;
	border-radius: 50%;
	text-align: center;
	vertical-align: middle;
	cursor: pointer;
}

.checkbox-btn .icon-ok {
	position: relative;
	display: none;
	width: 100%;
	height: 100%;
	fill: #fff;
	-webkit-transform: scale(0.6);
	-ms-transform: scale(0.6);
	transform: scale(0.6);
	vertical-align: top;
}

.checkbox-btn.checked {
	background-color: #ee7a23;
	border-color: #ee7a23;
}

.checkbox-btn.checked .icon-ok {
	display: inline-block;
}

.checkbox-btn.orange.checked {
	background-color: #ee7a23;
	border-color: #ee7a23;
}
</style>
