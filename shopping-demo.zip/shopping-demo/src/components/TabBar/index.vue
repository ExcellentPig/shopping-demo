<template>
	<footer id="footer">
		<ul>
			<router-link tag="li" to="/cartlist">
				<i class="iconfont icon-shangpin"></i>
				<p>商品</p>
			</router-link>
			<router-link tag="li" to="/mycart">
				<i class="iconfont icon-gouwuchekong"></i>
				<div class="mt" v-if="cartCount>0">
					{{cartCount}}
				</div>
				<p>购物车</p>
			</router-link>
			<router-link tag="li" to="/mine">
				<i class="iconfont icon-wode"></i>
				<p>我的</p>
			</router-link>
		</ul>
	</footer>
</template>

<script>
export default {
	name: 'TabBar',
	data(){
		return {
			
		}
	},
	methods:{
		
	},
	computed:{
		cartCount(){
			return this.$store.state.cartnum.cartCount
		}
	}
};
</script>

<style scoped="scoped">
	.mt{
		width: 20px;
		height: 20px;
		border-radius: 50%;
		background-color: red;
		position: absolute;
		top: 0;
		left: 51%;
		bottom: 0;
		right: 0;
		font-size: 10px;
		text-align: center;
		line-height: 20px;
		color: white;
		opacity: .6;
	}
#footer {
	width: 100%;
	height: 50px;
	background: white;
	border-top: 2px #ebe8e3 solid;
	position: fixed;
	left: 0;
	bottom: 0;
}
#footer ul {
	display: flex;
	text-align: center;
	height: 50px;
	align-items: center;
}
#footer ul li {
	flex: 1;
	height: 40px;
}
#footer ul li.active {
	color: #f03d37;
}
#footer ul li.router-link-active {
	color: #f03d37;
}
#footer ul i {
	font-size: 20px;
}
#footer ul p {
	font-size: 12px;
	line-height: 18px;
}
</style>
