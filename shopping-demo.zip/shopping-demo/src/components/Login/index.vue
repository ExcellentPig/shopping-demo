<template>
	<div class="login_body">
		<div><input v-model="userName" class="login_text" type="text" placeHolder="请输入你的用户名" /></div>
		<div><input v-model="userPwd" class="login_text" type="password" placeHolder="请输入您的密码" /></div>
		<div class="img">
			<input v-model="verifyImg" class="login_text" type="text" placeHolder="请输入您的验证码" />
			<img @touchstart="handleToVerifyUp" src="/users/verifyImg" />
		</div>
		<div class="login_btn"><input type="submit" value="登录" @touchstart="handleToLogin" /></div>
		<div class="login_link">
			<router-link tag="a" to="/mine/register">立即注册</router-link>
			<router-link tag="a" to="/mine/findPassword">找回密码</router-link>
		</div>
	</div>
</template>

<script>
import {messageBox} from '@/components/JS'
import axios from 'axios';
export default {
	name: 'Login',
	data() {
		return {
			userName: '',
			userPwd: '',
			verifyImg:''
		};
	},
	methods: {
		handleToLogin() {
			axios
				.post('/users/login', {
					userName: this.userName,
					userPwd: this.userPwd,
					verifyImg:this.verifyImg
				})
				.then(res => {
					var status = res.data.status;
					var This = this;
					if (status === 0) {
						messageBox({
							title:'登录',
							content:'登陆成功',
							ok:'确定',
							handleOk(){
								This.$router.push('/mine/center')
								This.getCartCount();
							}
						})
					} else {
						messageBox({
							title:'登录',
							content:res.data.msg,
							ok:'确定'
						})
					}
				});
		},
		handleToVerifyUp(ev){
			ev.target.src = '/users/verifyImg?'+Math.random();
		},
		getCartCount(){
			this.axios.get("/carts/getCartCount")
				.then(response=>{
					var res = response.data;
					localStorage.setItem('cartCount', res.result);
					this.$store.commit('cartnum/initCartCount',res.result);
				})
		}
	}
};
</script>

<style scoped>
	.img img{
		margin-left: 40%;
	}
#content .login_body {
	width: 100%;
}
.login_body .login_text {
	width: 100%;
	height: 40px;
	border: none;
	border-bottom: 1px #ccc solid;
	margin-bottom: 5px;
	outline: none;
	text-indent: 10px;
}
.login_body .login_btn {
	height: 50px;
	margin: 10px;
}
.login_body .login_btn input {
	width: 100%;
	height: 100%;
	background: #ff7d63;
	border-radius: 3px;
	border: none;
	display: block;
	color: white;
	font-size: 20px;
}
.login_body .login_link {
	display: flex;
	justify-content: space-between;
}
.login_body .login_link a {
	text-decoration: none;
	margin: 0 5px;
	font-size: 12px;
	color: #e54847;
}
</style>
